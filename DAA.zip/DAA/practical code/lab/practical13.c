#include <stdio.h>
#include <string.h>

// Naive string matching algorithm
void naiveStringMatching(char* text, char* pattern) {
    int n = strlen(text);    // Length of text
    int m = strlen(pattern); // Length of pattern

    // Loop through the text, checking each substring
    for (int i = 0; i <= n - m; i++) {
        int j;
        // Compare the substring of text starting at i with the pattern
        for (j = 0; j < m; j++) {
            if (text[i + j] != pattern[j])
                break;
        }
        // If the pattern matches, print the starting index
        if (j == m) {
            printf("Pattern found at index %d\n", i);
        }
    }
}

int main() {
    char text[100], pattern[50];

    // Take input for the text
    printf("Enter the text: ");
    gets(text);

    // Take input for the pattern
    printf("Enter the pattern: ");
    gets(pattern);

    // Call the naive string matching algorithm
    naiveStringMatching(text, pattern);

    return 0;
}
