#include <stdio.h>
#include <limits.h>

// Function to calculate the total distance for a given route
int calculateCost(int graph[][10], int route[], int n) {
    int cost = 0;
    for (int i = 0; i < n - 1; i++) {
        cost += graph[route[i]][route[i + 1]];
    }
    cost += graph[route[n - 1]][route[0]]; // Return to starting point
    return cost;
}

// Function to swap two integers
void swap(int* x, int* y) {
    int temp = *x;
    *x = *y;
    *y = temp;
}

// Function to generate all permutations of cities and find the minimum cost
void tsp(int graph[][10], int route[], int l, int r, int n, int* min_cost) {
    if (l == r) {
        // Calculate cost of the current route
        int cost = calculateCost(graph, route, n);
        if (cost < *min_cost) {
            *min_cost = cost;
            printf("Route: ");
            for (int i = 0; i < n; i++) {
                printf("%d ", route[i]);
            }
            printf("\nCost: %d\n\n", cost);
        }
    } else {
        for (int i = l; i <= r; i++) {
            swap(&route[l], &route[i]);
            tsp(graph, route, l + 1, r, n, min_cost);
            swap(&route[l], &route[i]); // Backtrack
        }
    }
}

int main() {
    int n;

    // Take input for the number of cities
    printf("Enter the number of cities: ");
    scanf("%d", &n);

    // Take input for the distance matrix
    int graph[10][10];
    printf("Enter the distance matrix:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Array to store the cities (excluding the starting city)
    int route[10];
    for (int i = 0; i < n; i++) {
        route[i] = i;
    }

    int min_cost = INT_MAX;

    // Start the TSP brute-force algorithm
    tsp(graph, route, 0, n - 1, n, &min_cost);

    // Output the minimum cost
    printf("Minimum cost: %d\n", min_cost);

    return 0;
}
