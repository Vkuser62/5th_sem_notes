#include<stdio.h>
#include<string.h>
char b[100][100],x[100],y[100];
void main()
{

    printf("\nEnter the Sequence 1 : ");
    scanf("%s",x);
    printf("\nEnter the Sequence 2 : ");
    scanf("%s",y);
    lcs(x,y);

}


void lcs(char x[],char y[])
{
    int m,n,c[100][100],i,j;
    m = strlen(x);
    n = strlen(y);

    for(i=0;i<=m;i++)
    {
        for(j=0;j<=n;j++)
        {
            c[i][j] = 0;
        }
    }

    for(i=1;i<=m;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(x[i-1] == y[j-1])
            {
                c[i][j] = c[i-1][j-1] + 1;
                b[i][j] = 'd';
            }
            else if(x[i-1] != y[j-1])
            {
                if(c[i-1][j] > c[i][j-1])
                {
                    c[i][j] = c[i-1][j];
                    b[i][j] = 'u';
                }
                else
                {
                    c[i][j] = c[i][j-1];
                    b[i][j] = 'l';
                }
            }
        }
    }



    for(i=0;i<=m;i++)
    {
        for(j=0;j<=n;j++)
        {
            printf("%5d",c[i][j]);
        }
        printf("\n");
    }
    printf("\n\n");
    for(i=0;i<=m;i++)
    {
        for(j=0;j<=n;j++)
        {
            printf("%5c",b[i][j]);
        }
        printf("\n");
    }


printf("\n\nLCS : ");
backtrack(m,n);
}

void backtrack(int i,int j)
{
    if(i==0 || j==0)
    {
        return;
    }
    else if(b[i][j] == 'd')
    {
        backtrack(i-1,j-1);
        printf("%c",x[i-1]);
    }
    else if(b[i][j] == 'u')
    {
        backtrack(i-1,j);
    }
    else
    {
        backtrack(i,j-1);
    }
}
