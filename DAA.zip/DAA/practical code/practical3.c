/* Develop a program to implement Merge sort and Quicksort and perform time analysis 
of sorting algorithms. */

#include <stdio.h>

// Function to swap two elements
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function for Quick Sort partitioning
int partition(int a[], int beg, int end) {
    int pivot = a[beg];
    int up = end;
    int down = beg;

    while (down < up) {
        while (a[down] <= pivot && down < end)
            down++;
        while (a[up] > pivot)
            up--;
        if (down < up)
            swap(&a[down], &a[up]);
    }

    swap(&a[beg], &a[up]);
    return up;
}

// Function to perform Quick Sort
void quickSort(int a[], int beg, int end) {
    if (beg < end) {
        int pivotIndex = partition(a, beg, end);
        quickSort(a, beg, pivotIndex - 1);
        quickSort(a, pivotIndex + 1, end);
    }
}

void merge(int arr[], int low1, int high1, int high2) {
    int i, j, k;
    int aux[high2 - low1 + 1];
    i = low1;
    j = high1 + 1;
    k = 0;

    while (i <= high1 && j <= high2) {
        if (arr[i] <= arr[j]) {
            aux[k] = arr[i];
            k++;
            i++;
        } else {
            aux[k] = arr[j];
            k++;
            j++;
        }
    }

    while (i <= high1) {
        aux[k] = arr[i];
        k++;
        i++;
    }

    while (j <= high2) {
        aux[k] = arr[j];
        k++;
        j++;
    }

    k = 0;
    for (j = low1; j <= high2; j++) {
        arr[j] = aux[k];
        k++;
    }
}

void mergesort(int arr[], int low, int high) {
    if (low < high) {
        int mid = (low + high) / 2;
        mergesort(arr, low, mid);
        mergesort(arr, mid + 1, high);
        merge(arr, low, mid, high);
    }
}

int main() {
    int n, choice;
    printf("Choose the sorting algorithm:\n");
    printf("1. Merge Sort\n");
    printf("2. Quick Sort\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    printf("Enter the number of elements: ");
    scanf("%d", &n);
    int arr[n];

    printf("Enter the elements:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    switch (choice) {
        case 1:
            printf("Performing Merge Sort...\n");
            mergesort(arr, 0, n - 1);
            break;
        case 2:
            printf("Performing Quick Sort...\n");
            quickSort(arr, 0, n - 1);
            break;
        default:
            printf("Invalid choice!\n");
            return 1;
    }

    printf("Sorted array in ascending order:\n");
    for (int i = 0; i < n; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}