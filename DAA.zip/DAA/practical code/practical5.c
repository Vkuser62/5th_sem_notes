#include<stdio.h>

void knapsack(int,float[],float[],int);

void main()
{
    int n,i,cap;
    float w[100],v[100];
    printf("\nEnter the no. of Item : ");
    scanf("%d",&n);

    for(i = 1; i<=n; i++)
    {
        printf("\nEnter the weight of item[%d] : ",i);
        scanf("%f",&w[i]);

        printf("\nEnter the value of the iten[%d] :" , i);
        scanf("%f",&v[i]);
    }
    printf("\nEnter the CAPACITY :  ");
    scanf("%d",&cap);

    knapsack(n,w,v,cap);
}

    void knapsack(int n, float w[], float v[],int cap)
    {
        float ratios[100],temp,x[100],profit = 0.0;
        int i,j;
        for(i = 1; i<=n; i++)
        {
            ratios[i] = v[i]/w[i];
        }

        for(i=1; i<=n;i++)
        {
            printf("%5.1f",ratios[i]);
        }
        for(i=1; i<=n;i++)
        {
            for(j=1;j<=(n-i); j++)
            {
                if(ratios[j] < ratios[j+1])
                {
                    temp = ratios[j];
                    ratios[j]= ratios[j+1];
                    ratios[j+1] = temp;

                    temp = w[j];
                    w[j] = w[j+1];
                    w[j+1] = temp;
                    
                    temp = v[j];
                    v[j] = v[j+1];
                    v[j+1] = temp;

                }
            }
        }
        printf("\n\n");
        printf("Weight : ");
        for(i = 1; i<=n; i++)
        {
            printf("%5.1f",w[i]);
        }
        printf("\n");
        printf("Value : ");
        for(i = 1; i<=n; i++)
        {
            printf("%5.1f",v[i]);
        }
        printf("\n");
        printf("Ratios : ");
        for(i = 1; i<=n; i++)
        {
            printf("%5.1f",ratios[i]);
        }
        for( i = 1; i<=n; i++)
        {
            if(w[i] < cap)
            {
                x[i] = 1.0;
                profit = profit + (x[i] * v[i]);
                cap = cap - w[i];
            }
            else
            {
                x[i] = cap/w[i];
                profit = profit + (x[i] * v[i]);
                break;
            }
        }
        printf("\n");
        printf("XARRAY :");
        for(i = 1; i<=n; i++)
        {
            printf("%5.1f",x[i]);
        }
        printf("\n\nProfit = %.0f\n\n" , profit);
}