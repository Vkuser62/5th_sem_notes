/* Write a Program to implement Bubble sort, Selection sort, and Insertion sort and 
    perform time analysis of these sorting algorithms. */

#include <stdio.h>

void bubble_sort(int a[], int n) {
    int i, j, temp;
    for (i = 1; i < n; i++) {
        for (j = 0; j < n - i; j++) {
            if (a[j] > a[j + 1]) {
                temp = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp;
            }
        }
    }
    printf("Bubble Sorted array is: ");
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void selection_sort(int a[], int n) {
    int i, j, min_idx, temp;
    for (i = 0; i < n - 1; i++) {
        min_idx = i;
        for (j = i + 1; j < n; j++) {
            if (a[j] < a[min_idx]) {
                min_idx = j;
            }
        }
        temp = a[min_idx];
        a[min_idx] = a[i];
        a[i] = temp;
    }
    printf("Selection Sorted array is: ");
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

void insertion_sort(int a[], int n) {
    int i, key, j;
    for (i = 1; i < n; i++) {
        key = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > key) {
            a[j + 1] = a[j];
            j = j - 1;
        }
        a[j + 1] = key;
    }
    printf("Insertion Sorted array is: ");
    for (i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
    printf("\n");
}

int main() {
    int a[50], n, i, choice;
    printf("Enter size of Array: ");
    scanf("%d", &n);
    printf("Enter array elements: ");
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }

    printf("Choose sorting algorithm:\n1. Bubble Sort\n2. Selection Sort\n3. Insertion Sort\nEnter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1:
            bubble_sort(a, n);
            break;
        case 2:
            selection_sort(a, n);
            break;
        case 3:
            insertion_sort(a, n);
            break;
        default:
            printf("Invalid choice!\n");
            break;
    }

    return 0;
}