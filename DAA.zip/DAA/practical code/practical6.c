#include <stdio.h>

void activitySelection(int , int[],  int[]);

int main() {
    int n, i;

    printf("Enter the number of activities: ");
    scanf("%d", &n);

    int start[n], finish[n];

    for (i = 0; i < n; i++) {
        printf("Enter the start  time of activity %d : ", i + 1);
        scanf("%d", &start[i]);
        printf("Enter the finish timie of activity %d : " , i + 1 );
        scanf("%d" ,&finish[i]);
    }

    activitySelection(n, start, finish);

    return 0;
}

void activitySelection(int n, int start[], int finish[]) {
    int i, j;

    printf("Selected activities are: \n");
    i = 0;
    printf("Activity %d (Start: %d, Finish: %d)\n", i + 1, start[i], finish[i]);

    for (j = 1; j < n; j++) {
        if (start[j] >= finish[i]) {
            printf("Activity %d (Start: %d, Finish: %d)\n", j + 1, start[j], finish[j]);
            i = j;
        }
    }
}


