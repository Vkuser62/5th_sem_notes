#include<stdio.h>

void makingchange(int,int[],int);

void main()
{
    int n,d[10],a,i;
    printf("\nEnter the no of dimension coins : ");
    scanf("%d",&n);

    for(i=1; i<=n; i++)
    {
        printf("\n Enter the dimession coin[%d] : ",i);
        scanf("%d",&d[i]);
    }

    printf("\nAmount to be made : ");
    scanf("%d",&a);

    makingchange(n,d,a);
    
}
void makingchange(int n,int d[], int a)
{
    int i,j,c[100][100] ,s[10],t=0;
    for(i=0; i<=n;i++)
    {
        for(j=0; j<=a; j++)
        {
            c[i][j] = 0;
        }    
    }
    for( i = 1; i<=n; i++)
    {
        for(j=1;j<=a;j++)
        {
        if( i == 0 && j<d[i])
        {
            c[i][j] = 100;
        }
        else if(i == 1)
        {
            c[i][j] = 1 + c[i][j-d[1]];
        }
        else if(j<d[i])
        {
            c[i][j] = c[i-1][j];
        }
        else
        {
            if(c[i-1][j] < (1 + c[i][j-d[i]]))
            {
                c[i][j] = c[i-1][j];
            }
            else
            {
                c[i][j] = 1 + c[i][j-d[i]];
            }
        }
    }
    }

    for( i = 0; i<=n; i++)
    {
        for(j=0; j<=a; j++)
        {
            printf("%5d",c[i][j]);
        }
        printf("\n");
    }
    printf("Minimun Coins : %d", c[n][a]);

    i = n;
    j = a;
    while (j>0)
    {
       if(c[i][j] == c[i-1][j])
       {
        i--;
       }
       else
       {
         s[t] = d[i];
         t++;
         j = a -d[i];
         a = a -d[i];
       }
    }

    printf("\n\nCoins Used : ");
    for(i = 0; i<t; i++){
        printf("%5d" ,s[i]);
    }
    printf("\n\n");
    
}


